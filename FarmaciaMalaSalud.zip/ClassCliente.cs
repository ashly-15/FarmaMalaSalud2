﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FarmaciaMBS
{
    class ClassCliente
    {
        private char id_cliente;
        private string nombres;
        private string apellidos;
        private char cedula;
        private int telefono;
        private string direccion;
        private string tipocliente;

        public char IdCliente { get; set; }
        public string Nombres { get; set; }
        public string Apellidos { get; set; }
        public char Cedula { get; set; }
        public int Telefono { get; set; }
        public string Dirrecion { get; set; }
        private string Tipocliente { get; set; }

        public ClassCliente() { }

        public ClassCliente(char id_cliente, string nombres, string apellidos, char cedula,
            int telefono, string direccion, string tipocliente)
        {
            this.IdCliente = id_cliente;
            this.Nombres = nombres;
            this.Apellidos = apellidos;
            this.Cedula = cedula;
            this.Telefono = telefono;
            this.Dirrecion = direccion;
            this.Tipocliente = tipocliente;
        }

        public void AgregarCliente()
        {

        }

        public void ModificarCliente()
        {

        }

        public void EliminarCliente()
        {

        }
    }
}
