﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FarmaciaMBS
{
    class ClassEmpleado
    {
        private char id_empleado;
        private string nombres;
        private string apellidos;
        private char cedula;
        private int telefono;
        private string email;
        private string direccion;
        private int id_cargo;
        private char genero;
        private char usuario;
        private char contraseña;

        public char IdEmpleado { get; set; }
        public string Nombres { get; set; }
        public string Apellidos { get; set; }
        public char Cedula { get; set; }
        public int Telefono { get; set; }
        public string Email { get; set; }
        public string Direccion { get; set; }
        public int IdCargo { get; set; }
        public char Genero { get; set; }
        public char Usuario { get; set; }
        public char Contraseña { get; set; }

        public ClassEmpleado() { }

        public ClassEmpleado(char id_empleado, string nombres, string apellidos, char cedula,
            int telefono, string email, string direccion, int id_cargo, char genero)
        {
            this.IdEmpleado = id_empleado;
            this.Nombres = nombres;
            this.Apellidos = apellidos;
            this.Cedula = cedula;
            this.Telefono = telefono;
            this.Email = email;
            this.Direccion = direccion;
            this.IdCargo = id_cargo;
            this.Genero = genero;
            this.Usuario = usuario;
            this.Contraseña = contraseña;
        }

        public void RegistrarEmpleado()
        {

        }

        public void ModificarEmpleado()
        {

        }

        public void EliminarEmpleado()
        {

        }
    }
}
