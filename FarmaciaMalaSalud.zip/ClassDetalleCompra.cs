﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FarmaciaMBS
{
    class ClassDetalleCompra
    {
        private int id_detalle_compra;
        private int id_compra;
        private char id_producto;
        private int cantidad;
        private decimal precio;
        private decimal subtotalcompra;

        public int IdDetalleCompra { get; set; }
        public int IdCompra { get; set; }
        public char IdProducto { get; set; }
        public int Cantidad { get; set; }
        public decimal Precio { get; set; }
        public decimal SubtotalCompra { get; set; }

        public ClassDetalleCompra() { }

        public ClassDetalleCompra(int id_detalle_compra, int id_compra, char id_producto, int cantidad, decimal precio, decimal subtotalcompra)
        {
            IdDetalleCompra = id_detalle_compra;
            IdCompra = id_compra;
            IdProducto = id_producto;
            Cantidad = cantidad;
            Precio = precio;
            SubtotalCompra = subtotalcompra;
        }

        private void CapturarDatos()
        {

        }

        private void EnviarCompra()
        {

        }

        public virtual double Calcularsubtotal(decimal Precio, int Cantidad)
        {
            subtotalcompra = Cantidad * Precio;
            return Math.Round((double)subtotalcompra, 2);
        }
        }
    }
