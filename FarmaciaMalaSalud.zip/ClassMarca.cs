﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FarmaciaMBS
{
    class ClassMarca
    {
        private int id_marca;
        private string nombremarca;

        public int IdMarca { get; set; }
        public string NombreMarca { get; set; }

        public ClassMarca() { }

        public ClassMarca(int id_marca, string nombremarca)
        {
            IdMarca = id_marca;
            NombreMarca = nombremarca;
        }

        private void RegistrarMarca()
        {

        }

        private void EditarMarca()
        {

        }

        private void EliminarMarca()
        {

        }
    }
}
