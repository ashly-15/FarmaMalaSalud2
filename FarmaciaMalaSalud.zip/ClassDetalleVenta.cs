﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FarmaciaMBS
{
    class ClassDetalleVenta
    {
        private int id_detalle_venta;
        private int id_factura;
        private char id_producto;
        private int cantvendida;
        private decimal precio;
        private decimal iva;
        private decimal subtotalfactura;

        public int Id_detalle_venta { get; set; }
        public int Id_factura { get; set; }
        public char Id_producto { get; set; }
        public int Cantvendida { get; set; }
        public decimal Precio { get; set; }
        public decimal IVA { get; set; }
        public decimal SubtotalFactura { get; set; }

        public ClassDetalleVenta() { }

        public ClassDetalleVenta(int id_detalle_venta, int id_factura, char id_producto, int cantvendida, decimal precio,
            decimal iva, decimal subtotalfactura)
        {
            this.Id_detalle_venta = id_detalle_venta;
            this.Id_factura = id_factura;
            this.Id_producto = id_producto;
            this.Cantvendida = cantvendida;
            this.Precio = precio;
            this.IVA = iva;
            this.SubtotalFactura = subtotalfactura;
        }

        public virtual double Calcularsubtotal(decimal Precio, int Cantvendida)
        {
            subtotalfactura = Cantvendida * Precio;
            return Math.Round((double)subtotalfactura, 2);
        }

        public virtual double CalcularIVA(decimal precio, decimal iva)
        {
            iva = Precio * 1.15m;
            return Math.Round((double)iva, 2);
        }
        }
    }
