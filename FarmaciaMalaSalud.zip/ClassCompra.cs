﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FarmaciaMBS
{
    class ClassCompra
    {
        private int id_compra;
        private char id_empleado;
        private char id_proveedor;
        private DateTime fechacompra;
        private decimal totalcompra;

        public int IdCompra { get; set; }
        public char IdEmpleado { get; set; }
        public char IdProveedor { get; set; }
        public DateTime FechaCompra { get; set; }
        public decimal TotalCompra { get; set; }

        public ClassCompra() { }

        public ClassCompra(int id_compra, char id_empleado, char id_proveedor, DateTime fechacompra, decimal totalcompra)
        {
            IdCompra = id_compra;
            IdEmpleado = id_empleado;
            IdProveedor = id_proveedor;
            FechaCompra = fechacompra;
            TotalCompra = totalcompra;
        }

        public decimal CalcularTotalCompra()
        {
            decimal total = 0;
            return total;
        }
    }
}
