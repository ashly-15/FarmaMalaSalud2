﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FarmaciaMBS
{
    class ClassProducto
    {
        private char id_producto;
        private string nombreproducto;
        private int stockminimo;
        private int id_categoria;
        private int id_marca;

        public char Idproducto { get; set; }
        public string Nombreproducto { get; set; }
        public int StockMinimo { get; set; }
        public int IdCategoria { get; set; }
        public int IdMarca { get; set; }

        public ClassProducto() { }

        public ClassProducto(char id_producto, string nombreproducto, int id_categoria, int id_marca)
        {
            Idproducto = id_producto;
            Nombreproducto = nombreproducto;
            IdCategoria = id_categoria;
            IdMarca = id_marca;
        }

        public double CalcularDescuento(double precio)
        {
            return precio;
        }

        public void RegistrarProductos()
        {

        }

        public void ModificarProducto()
        {

        }

        public void EliminarProducto()
        {

        }

        public void ObtenerStock()
        {

        }
    }
}
