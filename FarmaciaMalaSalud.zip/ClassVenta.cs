﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FarmaciaMBS
{
    class ClassVenta
    {
        private int id_venta;
        private string tipoventa;
        private char id_empleado;
        private int id_cliente;
        private DateTime fechaventa;
        private decimal totalventa;
        private string tipopago;

        public int IdVenta { get; set; }
        public string TipoVenta { get; set; }
        public char IdEmpleado { get; set; }
        public char IdCliente { get; set; }
        public DateTime FechaVenta { get; set; }
        public decimal TotalVenta { get; set; }
        public string TipoPago { get; set; }

        public ClassVenta() { }

        public ClassVenta(int id_venta, string tipoventa, char id_empleado, char id_cliente, DateTime fechaventa,
            decimal totalventa, string tipopago)
        {
            IdVenta = id_venta;
            TipoVenta = tipoventa;
            IdEmpleado = id_empleado;
            IdCliente = id_cliente;
            FechaVenta = fechaventa;
            TotalVenta = totalventa;
            TipoPago = tipopago;
        }

        public void CapturarDatos()
        {

        }

        public void ActivarControles()
        {

        }

        public void LimpiarControles()
        {

        }
        public void DesactivarControles()
        {

        }

        public decimal CalcularTotalVenta()
        {
            decimal total = 0;
            return total;
        }
    }
}
