﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FarmaciaMBS
{
    class ClassControlCredito
    {
        private int idcontrolcredito;
        private int idcredito;
        private int cuota;
        private decimal saldo;
        private DateTime fechaabono;

        public int IdControlCredito { get; set; }
        public int IdCredito { get; set; }
        public int Cuota { get; set; }
        public decimal Saldo { get; set; }
        public DateTime FechaAbono { get; set; }

        public ClassControlCredito() { }

        public ClassControlCredito(int idcontrolcredito, int idcredito, int cuota, decimal saldo, DateTime fechaabono)
        {
            IdControlCredito = idcontrolcredito;
            IdCredito = idcredito;
            Cuota = cuota;
            Saldo = saldo;
            FechaAbono = fechaabono;
        }

        private void CapturarAbono()
        {

        }

        private decimal CalcularSaldo(decimal saldo)
        {
            return saldo;
        }
    }
}

