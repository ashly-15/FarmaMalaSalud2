﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FarmaciaMBS
{
    class ClassProveedor
    {
        private char id_proveedor;
        private string nombres;
        private string apellidos;
        private char cedula;
        private int telefono;
        private string empresa;
        private string estado;

        public char IdProveedor { get; set; }
        public string Nombres { get; set; }
        public string Apellidos { get; set; }
        public char Cedula { get; set; }
        public int Telefono { get; set; }
        public string Empresa { get; set; }
        private string Estado { get; set; }

        public ClassProveedor() { }

        public ClassProveedor(char id_proveedor, string nombres, string apellidos, char cedula,
            int telefono, string empresa, string estado)
        {
            this.IdProveedor = id_proveedor;
            this.Nombres = nombres;
            this.Apellidos = apellidos;
            this.Cedula = cedula;
            this.Telefono = telefono;
            this.Empresa = empresa;
            this.Estado = estado;
        }

        public void AgregarProveedor()
        {

        }

        public void ModificarProveedor()
        {

        }

        public void EliminarProveedor()
        {

        }
    }
}
