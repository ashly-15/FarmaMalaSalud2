﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FarmaciaMBS
{
    class ClassCategoria
    {
        private int id_categoria;
        private string nombrecategoria;

        public int IdCategoria { get; set; }
        public string NombreCategoria { get; set; }

        public ClassCategoria() { }

        public ClassCategoria(int id_categoria, string nombrecategoria)
        {
            IdCategoria = id_categoria;
            NombreCategoria = nombrecategoria;
        }

        private void RegistrarCategoria()
        {

        }

        private void EditarCategoria()
        {

        }

        private void EliminarCategoria()
        {

        }
    }
}
