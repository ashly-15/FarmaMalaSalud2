﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FarmaciaMBS
{
    class ClassLote
    {
        private int idlote;
        private DateTime fechavencimientolote;

        public int IdLote { get; set; }
        public DateTime FechaVencimientoLote { get; set; }

        public ClassLote() { }

        public ClassLote(int idlote, DateTime fechavencimientolote)
        {
            IdLote = idlote;
            FechaVencimientoLote = fechavencimientolote;
        }
    }
}
