﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FarmaciaMBS
{
    class ClassDevolucion
    {
        private int id_devolucion;
        private int id_detalle_factura;
        private DateTime fechadevolucion;
        private string motivo;
        private int cantidaddevuelta;

        public int IdDevolucion { get; set; }
        public int IdDetalleFactura { get; set; }
        public DateTime FechaDevolucion { get; set; }
        public string Motivo { get; set; }
        private int CantidadDevuelta { get; set; }

        public ClassDevolucion() { }

        public ClassDevolucion(int id_devolucion, int id_detalle_factura, DateTime fechadevolucion, string motivo, int cantidaddevuelta)
        {
            IdDevolucion = id_devolucion;
            IdDetalleFactura = id_detalle_factura;
            FechaDevolucion = fechadevolucion;
            Motivo = motivo;
            CantidadDevuelta = cantidaddevuelta;
        }

        public void ObetenerNumeroFactura()
        {

        }

        private void AnularFactura()
        {

        }

        private void EntregarReeembolso()
        {

        }

        public void DevolverProductoInventario()
        {


        }
    }
}
