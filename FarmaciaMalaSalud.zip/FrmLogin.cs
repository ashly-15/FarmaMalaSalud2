﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ControladorOfc;

namespace FarmaciaMBS
{
    public partial class FrmLogin : Form
    {
        Login login1;

        public FrmLogin()
        {
            InitializeComponent();
        }

        private void txtContraseña_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnIniciar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtUsuario.Text.Trim()) || string.IsNullOrEmpty(txtContraseña.Text.Trim()))
            {
                MessageBox.Show("Ingrese sus datos", "Faltan datos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            Login templogin = new Login();
            if (!templogin.GetUsuarioExiste(txtUsuario.Text.Trim()))
            {
                MessageBox.Show("El usuario no existe", "Faltan datos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            else
            {
                this.login1 = new Login(templogin.GetIdUsuarioExistente(txtUsuario.Text.Trim()));

                string Hashed = Seguridad.Encriptar(txtContraseña.Text.Trim());
                if (this.login1.ValidarDatos(Hashed) == 2)
                {
                    MessageBox.Show("La contraseña es incorrecta", "Faltan datos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                using (FrmPrincipal frm = new FrmPrincipal())
                {
                    LimpiarCampos();
                    this.Hide();
                    frm.ShowDialog();
                }
                this.Show();
            }
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
            {
                CerrarForm();
                return true;
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }
        private void CerrarForm()
        {
            this.Close();
        }

        private void LimpiarCampos()
        {
            this.txtUsuario.Text = string.Empty;
            this.txtContraseña.Text = string.Empty;
        }
    }
}