﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FarmaciaMBS
{
    class ClassCredito
    {
        private int idcredito;
        private int idventa;
        private int plazo;
        private decimal montototal;

        public int IdCredito { get; set; }
        public int IdVenta { get; set; }
        public int Plazo { get; set; }
        public decimal MontoTotal { get; set; }

        public ClassCredito() { }

        public ClassCredito(int idcredito, int idventa, int plazo, decimal montototal)
        {
            IdCredito = idcredito;
            IdVenta = idventa;
            Plazo = plazo;
            MontoTotal = montototal;
        }
    }
}
